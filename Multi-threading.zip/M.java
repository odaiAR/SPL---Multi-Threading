package bgu.spl.mics.application.subscribers;

import bgu.spl.mics.Future;
import bgu.spl.mics.Subscriber;
import bgu.spl.mics.application.messages.*;
import bgu.spl.mics.application.passiveObjects.Diary;
import bgu.spl.mics.application.passiveObjects.Report;

import java.util.List;
import java.util.concurrent.CountDownLatch;

/**
 * M handles ReadyEvent - fills a report and sends agents to mission.
 * <p>
 * You can add private fields and public methods to this class.
 * You MAY change constructor signatures and even add new public constructors.
 */
public class M extends Subscriber {
    private CountDownLatch latch;
    private int serialnumber;
    private Diary diary = Diary.getInstance();
    private int tick = 0;

    public M(int serialnumber, CountDownLatch latch) {
        super("M");
        this.latch = latch;
        this.serialnumber = serialnumber;
    }

    @Override
    protected void initialize() {
        subscribeBroadcast(TerminateBroadcast.class, c -> terminate());
        subscribeBroadcast(TickBroadcast.class, c -> tick = c.getCurrtick().get());
        subscribeEvent(MissionReceivedEvent.class, c -> {
            diary.incrementTotal();
//------------------------agents event-------------------------------
            AgentsAvailableEvent a =
                    new AgentsAvailableEvent(c.getMission().getSerialAgentsNumbers(), c.getMission().getDuration());
            Future<List<String>> f = getSimplePublisher().sendEvent(a);
            if (f != null && f.get() != null) {
//------------------------Gadget event-------------------------------
                GadgetAvailableEvent g = new GadgetAvailableEvent(c.getMission().getGadget());
                Future<Integer> f1 = getSimplePublisher().sendEvent(g);
//------------------------the report --------------------------------
                if (f1 != null && f1.get() != null) {
                    if (tick <= c.getMission().getTimeExpired()) {
                        Report r = new Report();
                        while (r.getMoneypenny() == 0) {
                            r.setMoneypenny(a.getMoneynum());
                        }
                        r.setAgentsNames(f.get());
                        r.setQTime(f1.get());
                        r.setAgentsSerialNumbersNumber(a.getSerials());
                        r.setM(serialnumber);
                        r.setMissionName(c.getMission().getMissionName());
                        r.setTimeCreated(c.getTick());
                        r.setTimeIssued(c.getMission().getTimeIssued());
                        r.setGadgetName(c.getMission().getGadget());
                        if (!f.isDone() || (f.get() == null)) {
                            String[] p = new String[1];
                            p[0] = r.getGadgetName();
                            getSimplePublisher().sendBroadcast(new GadgetReleaseEvent(p));
                        }
                            diary.addReport(r);
                            complete(c, r);
                    }
                }
            }
            else {
                complete(c, null);
            }
        });
        latch.countDown();
    }
}
